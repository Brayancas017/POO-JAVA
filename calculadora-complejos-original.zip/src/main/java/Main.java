// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;

public class Main {
  public static void main(String[] args) {

    new Ventana();

    Complejo c = new Complejo();
    c.imprimir();
    c.leer();

    Complejo otroComplejo = new Complejo();
    otroComplejo.leer();
    c.suma(otroComplejo); // pasa como argumento otroComplejo al objeto c en el metodo suma
    c.resta(otroComplejo);
    c.multiplicacion(otroComplejo);
    c.division(otroComplejo);
  }

}
