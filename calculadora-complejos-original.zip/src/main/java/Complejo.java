import java.util.Scanner;

public class Complejo {

  private double real;// atributo
  private double imaginario; // atributo
  private Complejo otroComplejo;

  public void imprimir() { // metodo

    System.out.println("Calculadora numeros complejos");
  }

  public void leer() {

    Scanner entrada = new Scanner(System.in);
    System.out.println("Numero real: ");
    real = entrada.nextDouble();
    System.out.println("Numero imaginario: ");
    imaginario = entrada.nextDouble();
  }

  public void suma(Complejo otroComplejo) { // recibe como parametro el objeto otroComplejo de la clase Complejo
    double resultado_real = this.real + otroComplejo.real; // def variable local y suma la parte real y el objeto
                                                           // otroComplejo apunta a la parte real (.real) que recibio
                                                           // del metodo leer ejecutado en el main
    double resultado_imaginario = this.imaginario + otroComplejo.imaginario;
    System.out.println("La suma es: " + resultado_real + " + " + resultado_imaginario + "i");
  }

  public void resta(Complejo otroComplejo) {

    double resultado_real = this.real - otroComplejo.real;
    double resultado_imaginario = this.imaginario - otroComplejo.imaginario;
    System.out.println("La resta es: " + resultado_real + " - " + resultado_imaginario + "i");
  }

  public void multiplicacion(Complejo otroComplejo) {

    double real_1 = this.real * otroComplejo.real;
    double real_imaginario = this.real * otroComplejo.imaginario;
    double imaginario_real = this.imaginario * otroComplejo.real;
    double imaginario_imaginario = this.imaginario * otroComplejo.imaginario * -1;
    double resultado_1 = real_1 - imaginario_imaginario;
    double resultado_2 = real_imaginario + imaginario_real;
    System.out.println("Multiplicacion de numeros complejos: " + resultado_1 + "+" + resultado_2 + "i");

  }

  public void division(Complejo otroComplejo) {
    double numeradorReal = (this.real * otroComplejo.real) + (this.imaginario * otroComplejo.imaginario);
    double numeradorImaginario = (this.imaginario * otroComplejo.real) - (this.real * otroComplejo.imaginario);
    double denominadorReal = (otroComplejo.real * otroComplejo.real)
        + (otroComplejo.imaginario * otroComplejo.imaginario);

    System.out.println(
        "División de números complejos: (" + numeradorReal + " + " + numeradorImaginario + "i) / " + denominadorReal);
  }

  public void setReal(double real) { /// ingresar datos atributo pridao
    this.real = real;
  }

  public double getReal() { /// obtener datos atributo privado
    return this.real;
  }

  public void setImaginario(double imaginario) { /// ingresar datos atributo privado imaginario
    this.imaginario = imaginario;
  }

  public double getImaginario() { /// obtener datos atributo privado imaginario
    return this.imaginario;
  }
 
}  //cierre clase