import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana extends JFrame implements ActionListener {
  private JTextField real1Field, imaginario1Field, real2Field, imaginario2Field;
  private JButton sumaButton, restaButton, multiplicacionButton, divisionButton;
  private JLabel resultadoLabel;

  public Ventana() { //constructor
    real1Field = new JTextField(5);
    imaginario1Field = new JTextField(5);
    real2Field = new JTextField(5);
    imaginario2Field = new JTextField(5);
    sumaButton = new JButton("Suma");
    restaButton = new JButton("Resta");
    multiplicacionButton = new JButton("Multiplicación");
    divisionButton = new JButton("División");
    resultadoLabel = new JLabel();

    sumaButton.addActionListener(this);
    restaButton.addActionListener(this);
    multiplicacionButton.addActionListener(this);
    divisionButton.addActionListener(this);

    setLayout(new GridLayout(7, 2));
    add(new JLabel("Número real 1"));
    add(new JLabel("Número real 2"));
    add(real1Field);
    add(real2Field);
    add(new JLabel("Número imaginario 1"));
    add(new JLabel("Número imaginario 2"));
    add(imaginario1Field);
    add(imaginario2Field);
    add(sumaButton);
    add(restaButton);
    add(multiplicacionButton);
    add(divisionButton);
    add(new JLabel("Resultado"));
    add(resultadoLabel);

    this.pack();
    setTitle("Números Complejos");
    setSize(300, 200);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setVisible(true);
  } //cieere constructor

  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == sumaButton) {
      double real1 = Double.parseDouble(real1Field.getText());
      double imaginario1 = Double.parseDouble(imaginario1Field.getText());
      double real2 = Double.parseDouble(real2Field.getText());
      double imaginario2 = Double.parseDouble(imaginario2Field.getText());

      Complejo complejo1 = new Complejo();
      complejo1.setReal(real1);
      complejo1.setImaginario(imaginario1);

      Complejo complejo2 = new Complejo();
      complejo2.setReal(real2);
      complejo2.setImaginario(imaginario2);

      complejo1.suma(complejo2);
      resultadoLabel.setText("Resultado de la suma: " + complejo1.getReal() + " + " + complejo1.getImaginario() + "i");

    } //cierre if 
    
    else if (e.getSource() == restaButton) {

    } 
    
    else if (e.getSource() == multiplicacionButton) {

    } 
    
    else if (e.getSource() == divisionButton) {

    }
  } //cierre metodo
} //cierre clase