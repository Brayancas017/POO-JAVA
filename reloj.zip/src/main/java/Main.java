import java.time.LocalDateTime;
import java.time.ZoneId;

public class Main {
  public static void main(String[] args) {
    // Obtener la hora actual en Bogotá
    LocalDateTime horaActual = LocalDateTime.now(ZoneId.of("America/Bogota"));

    // Configurar el reloj con la hora actual
    Reloj reloj = new Reloj(horaActual.getHour(), horaActual.getMinute(), horaActual.getSecond());

    new Ventana();

    while (true) {
      reloj.incremento_seg();
    }
  }
}