public class Reloj{

  int hora;
  int minuto;
  int segundo;

  public Reloj(int hora, int minuto, int segundo) { //constructor
      this.hora = hora;
      this.minuto = minuto;
      this.segundo = segundo;
  }
  
  public void incremento_seg(){
    segundo++;
    if (this.segundo == 60){
      this.segundo = 0;
      incremento_min();
    }
    //imprimir();
    
    try {
        Thread.sleep(1000); // Pausa de 1 segundo
    } catch (InterruptedException e) {
        e.printStackTrace();
    }
  }

    private void incremento_min(){
      minuto++;
      if (this.minuto == 60){
        this.minuto= 0; 
        incremento_hor();
      }
    }
  
    private void incremento_hor(){
      hora++;
      if (this.hora == 24){
        this.hora= 0; 
      }
  }

  Reloj(){
    this.hora = 0;
    this.minuto = 0;
    this.segundo = 0;
  }
  
}