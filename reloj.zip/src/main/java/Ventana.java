import javax.swing.JFrame;
import javax.swing.JLabel;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Timer;
import java.util.TimerTask;

public class Ventana extends JFrame {
  private JLabel etiqueta;
  private Reloj reloj;

  public Ventana() {
    reloj = new Reloj();
    etiqueta = new JLabel();

    setTitle("Reloj Digital");
    setSize(200, 100);
    this.getContentPane().add(etiqueta);
    this.setVisible(true);

    // Actualizar el reloj y la etiqueta con la hora actual
    LocalDateTime horaActual = LocalDateTime.now(ZoneId.of("America/Bogota"));
    reloj.hora = horaActual.getHour();
    reloj.minuto = horaActual.getMinute();
    reloj.segundo = horaActual.getSecond();
    etiqueta.setText(String.format("%02d:%02d:%02d", reloj.hora, reloj.minuto, reloj.segundo));

    Timer timer = new Timer();
    timer.scheduleAtFixedRate(new TimerTask() {
      @Override
      public void run() {
        reloj.incremento_seg();
        etiqueta.setText(String.format("%02d:%02d:%02d", reloj.hora, reloj.minuto, reloj.segundo));
      }
    }, 0, 1000);

  }

}