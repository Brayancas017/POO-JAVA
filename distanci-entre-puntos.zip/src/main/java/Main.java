
  import java.util.Scanner;

  public class Main {

      public static void main(String[] args) {
          Scanner scanner = new Scanner(System.in);

          System.out.print("Introduzca valor de x en primer punto: ");
          int x1 = scanner.nextInt();

          System.out.print("Introduzca valor de y en primer punto: ");
          int y1 = scanner.nextInt();

          System.out.println("Coordenadas punto #1: " + x1 + "," + y1);

          System.out.print("Introduzca valor de x en segundo punto: ");
          int x2 = scanner.nextInt();

          System.out.print("Introduzca valor de y en segundo punto: ");
          int y2 = scanner.nextInt();

          System.out.println("Coordenadas punto #2: " + x2 + "," + y2);

          Punto puntos = new Punto(x1, y1, x2, y2); 

          double distanciaPuntos = puntos.distanciaEntrePuntos();
          System.out.println("Distancia entre primer y segundo punto: " + distanciaPuntos);

          double distanciaOrigen = puntos.distanciaAlOrigen();
          System.out.println("Distancia entre origen y primer punto: " + distanciaOrigen);
      }
  }