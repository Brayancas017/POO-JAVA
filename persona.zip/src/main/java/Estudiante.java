public class Estudiante extends Persona{
  @Override //sobreescribir en la funcion de la otra clase de herencia, osea persona
  public void imprimir() {
      saludo = "Hola, soy un estudiante";
      System.out.println(saludo);
  }
}