public class Empleado extends Persona{
  @Override //sobreescribir en la funcion de la otra clase de herencia, osea persona
  public void imprimir() {
      saludo = "Hola, soy un empleado";
      System.out.println(saludo);
  }
}