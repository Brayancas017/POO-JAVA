public class Funcionario extends Empleado{
  @Override //sobreescribir en la funcion de la otra clase de herencia, osea persona
  public void imprimir() {
      saludo = "Hola, soy un empleado que es funcionario publico";
      System.out.println(saludo);
  }
}