public class Docente extends Empleado{
  @Override //sobreescribir en la funcion de la otra clase de herencia, osea persona
  public void imprimir() {
      saludo = "Hola, soy un Docente";
      System.out.println(saludo);
  }
}