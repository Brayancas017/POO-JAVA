public class Persona{

  String saludo; //atributo
  
  public Persona(){ //constructor
  this.saludo = "Hola, soy una persona";
  }  
  
  public void imprimir(){
  System.out.println(saludo);
  }
}


