public class EstudiantePosgrado extends Estudiante{
  @Override //sobreescribir en la funcion de la otra clase de herencia, osea persona
  public void imprimir() {
      saludo = "Hola, soy un estudiante de posgrado";
      System.out.println(saludo);
  }
}