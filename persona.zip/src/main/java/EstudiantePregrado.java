public class EstudiantePregrado extends Estudiante{
  @Override //sobreescribir en la funcion de la otra clase de herencia, osea persona
  public void imprimir() {
      saludo = "Hola, soy un estudiante de pregrado";
      System.out.println(saludo);
  }
}