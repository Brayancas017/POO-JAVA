public class Main {
  public static void main(String[] args) {
    
    Persona persona = new Persona();
    persona.imprimir();

    Estudiante estudiante = new Estudiante();
    estudiante.imprimir();

    EstudiantePregrado estudiantepregrado = new EstudiantePregrado();
    estudiantepregrado.imprimir();

    EstudiantePosgrado estudianteposgrado = new EstudiantePosgrado();
    estudianteposgrado.imprimir();

    Empleado empleado = new Empleado();
    empleado.imprimir();

    Funcionario funcionario = new Funcionario();
    funcionario.imprimir();

    Docente docente = new Docente();
    docente.imprimir();
    
 }

}